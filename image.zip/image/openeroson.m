im=imread('10.jpg');
x=im2bw(im);
se=[0 1 0;1 1 1;0 1 0];
im2=imopen(x,se);
imshow(im2);title('open image');