I=imread('3.jpg');
h = fspecial('sharp')
I2 = imfilter(I,h);
imshow(I),title('Original Image')
figure 
imshow(I2)
title('Filtered Image')
