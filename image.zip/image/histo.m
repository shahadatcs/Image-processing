im=imread('8.jpg');
img=rgb2gray(im); 
imhist(img);
%imshow(x);title('Histogram');