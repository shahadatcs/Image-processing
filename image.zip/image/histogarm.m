im=imread('10.jpg');
rgb  = zeros(size(im,1),size(im,2))
rgb = .298*im(:,:,1)+.587*im(:,:,2)+.114*im(:,:,3)

subplot(3,1,3)
imhist(rgb),title('histogram with func')