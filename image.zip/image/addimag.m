a=imread('2.jpg');
b=imread('8.jpg');

%image with by default function

b=imresize (a, [400,400]);
d= imresize (b, [400,400]);
r=imadd(b,d);
subplot(3,1,1),imshow(r),title('1st image');

%image with custome function
k=imresize(b,[size(a,1),size(a,2)]);
[x y]= size(k);
for i=1:x
    for j=1:y
        im3(i,j)=b(i,j)+d(i,j);
    end
end
subplot(3,1,2),imshow(im3),title('add image');
